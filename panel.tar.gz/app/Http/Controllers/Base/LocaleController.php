<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\Http\JsonResponse;
use Illuminate\Translation\Translator;
use Illuminate\Contracts\Translation\Loader;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Base\LocaleRequest;
use Pterodactyl\Traits\Helpers\AvailableLanguages;

class LocaleController extends Controller
{
    use AvailableLanguages;
    protected Loader $loader;

    public function __construct(Translator $translator)
    {
        $this->loader = $translator->getLoader();
    }

    /**
     * Returns translation data given a specific locale and namespace.
     */
    public function __invoke(LocaleRequest $request): JsonResponse
    {
        $localeInput = $request->input('locale');
        $namespaceInput = $request->input('namespace');

        $locales = strpos($localeInput, '+') !== false
            ? explode('+', $localeInput)
            : [$localeInput];

        $namespaces = strpos($namespaceInput, ',') !== false
            ? explode(',', $namespaceInput)
            : [$namespaceInput];

        $response = [];

        foreach ($locales as $locale) {
            foreach ($namespaces as $namespace) {
                $response[$locale][$namespace] = $this->i18n(
                    $this->loader->load($locale, $namespace)
                );
            }
        }

        return new JsonResponse($response, 200, [
            // Cache this in the browser for an hour, and allow the browser to use a stale
            // cache for up to a day after it was created while it fetches an updated set
            // of translation keys.
            'Cache-Control' => 'public, max-age=3600, stale-while-revalidate=86400',
            'ETag' => md5(json_encode($response, JSON_THROW_ON_ERROR)),
        ]);
    }

    /**
     * Convert standard Laravel translation keys that look like ":foo"
     * into key structures that are supported by the front-end i18n
     * library, like "{{foo}}".
     */
    protected function i18n(array $data): array
    {
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $data[$key] = $this->i18n($value);
            } else {
                // Find a Laravel style translation replacement in the string and replace it with
                // one that the front-end is able to use. This won't always be present, especially
                // for complex strings or things where we'd never have a backend component anyways.
                //
                // For example:
                // "Hello :name, the :notifications.0.title notification needs :count actions :foo.0.bar."
                //
                // Becomes:
                // "Hello {{name}}, the {{notifications.0.title}} notification needs {{count}} actions {{foo.0.bar}}."
                $data[$key] = preg_replace('/:([\w.-]+\w)([^\w:]?|$)/m', '{{$1}}$2', $value);
            }
        }

        return $data;
    }

    public function list(): JsonResponse
    {
        $languages = $this->getAvailableLanguages(true);
        
        // Include flag codes from translation files
        $result = [];
        foreach ($languages as $code => $name) {
            $flag = trans("dashboard/index.flag", [], $code);
            // If no flag translation exists, fallback to empty
            if ($flag === "dashboard/index.flag") {
                $flag = '';
            }
            $result[$code] = [
                'name' => $name,
                'flag' => $flag,
            ];
        }
        
        return response()->json($result);
    }
}
